function create_circular_graph()
addpath('hex_and_rgb_v1/');
% load graph matrix
load("/Volumes/homes/Maya/SAT_study/results/feature_importance/BBS/permutation_feature_importance/edge_level/Global_BBS_permutation_feature_importance.mat")
matrix = permutation_feature_importance_mat;

% load("/Volumes/homes/Maya/SAT_study/results/feature_importance/across_models/majority_vote/Verbal_top_5_percent_edges.mat")
% matrix = common_edges_matrix;

%SUBCORTICAL
% LH_subcortical_order = [1,3,6,8,10,12,14,16,18];
% RH_subcortical_order = [2,4,7,9,11,13,15,17,19];
% brainstem_order = [5];
% matrix_hemi_order = matrix(1:50, :);
% matrix_hemi_order(51:59, :) = matrix(100+LH_subcortical_order, :);
% matrix_hemi_order(60, :) = matrix(100+brainstem_order, :);
% matrix_hemi_order(61:69,:) = matrix(100+flip(RH_subcortical_order), :);
% matrix_hemi_order(70:119,:) = matrix(100:-1:51, :);
% 
% matrix_hemi_order = matrix(:,1:50);
% matrix_hemi_order(:,51:59) = matrix(:,100+LH_subcortical_order);
% matrix_hemi_order(: , 60) = matrix(:,100+brainstem_order);
% matrix_hemi_order(:, 61:69) = matrix(:,100+flip(RH_subcortical_order));
% matrix_hemi_order(:,70:119) = matrix(:, 100:-1:51);
% matrix = matrix_hemi_order;

% Threshold the matrix to show only strong edges
% top 10 edges

% Including both positive and negative contributions
% top_10 = maxk(unique(abs(matrix(:))), 10); 
% matrix(abs(matrix)<min(abs(top_10))) = 0; 

% Only positive contributions
top_10 = maxk(unique(matrix(:)), 50);
matrix(matrix<min(top_10)) = 0;


%matrix(matrix<0.08*max(matrix(:))) = 0;
% matrix = matrix*5;

% create colormaps for node and edge
NodeColorMap = SchaeferColorMap();

GrayMap = gray(length(matrix)) / 2 +[0.5,0.5,0.5];

% get Schaefer atlas' labels
sch_labels_path = '/Volumes/homes/Maya/Atlases/schaefer_parcellation/Schaefer2018_100Parcels_7Networks_order_info.txt';
labels_fid = fopen(sch_labels_path);
schaefer_names = textscan(labels_fid, '%s');
schaefer_names = schaefer_names{1}(1:6:end);
schaefer_names = cellfun(@(s) s(11:end), schaefer_names, 'uniform', 0);

% reorder the labels and matrix so RH_Vis will be next to LH_Vis for visualization
schaefer_names_hemi_order = [schaefer_names(1:end/2); flip(schaefer_names(end/2+1:end))];
hemi_order = [1:50 100:-1:51]';
matrix_hemi_order = matrix(hemi_order, hemi_order);

% SUBCORTICAL
% subcortical_names = readtable('/Volumes/homes/Maya/Atlases/subcortical_order.xlsx');
% subcortical_names = table2cell(subcortical_names);
% schaefer_names_hemi_order = [schaefer_names(1:end/2); subcortical_names(LH_subcortical_order); subcortical_names(brainstem_order); flip(subcortical_names(RH_subcortical_order)); flip(schaefer_names(end/2+1:end))];


graph = circularGraph(matrix_hemi_order, 'Label', schaefer_names_hemi_order, 'EdgeColorMap', GrayMap, 'NodeColorMap', NodeColorMap);
end
    
%subcortical_names = readtable('/Volumes/homes/Maya/Atlases/subcortical_order.xlsx');
%LH_subcortical_order = [1,3,6,8,10,12,14,16,18];
%RH_subcortical_order = [2,4,7,9,11,13,15,17,19];
%brainstem_order = [5];

%reordered_matrix = matrix(1:50, :);
%reordered_matrix(51:59, :) = matrix(100+LH_subcortical_order, :);
%reordered_matrix(60, :) = matrix(100+brainstem_order, :);
%reordered_matrix(61:69,:) = matrix(100+RH_subcortical_order, :);
%reordered_matrix(70:119,:) = matrix(100:-1:51, :);

%reordered_matrix = matrix(:,1:50);
%reordered_matrix(:,51:59) = matrix(:,100+LH_subcortical_order);
%reordered_matrix(: , 60) = matrix(:,100+brainstem_order);
%reordered_matrix(:, 61:69) = matrix(:,100+RH_subcortical_order);
%reordered_matrix(:,70:119) = matrix(:, 100:-1:51);




%reordered_names = [schaefer_names(1:end/2), subcortical_names[LH_subcortical_order], subcortical_names[brainstem_order]; subcortical_names[RH_subcortical_order], flip(schaefer_names(end/2+1:end)))


