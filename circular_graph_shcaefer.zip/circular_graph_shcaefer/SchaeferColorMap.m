function newmap = SchaeferColorMap()
% Hex colors by using eyedropper 
hex_colors.Vis = '721D81';
hex_colors.DorsAttn = '3E8B2A';
hex_colors.Default = 'D15558';
hex_colors.SalVentAttn = 'E45DF7';
hex_colors.SomMot = '6EA2CE';
hex_colors.Cont = 'F4BA49';
hex_colors.Limbic = 'F8FDD3';

% network list
networks = fields(hex_colors);
newmap = hex_colors;
% convert to RGB
for i = 1:length(networks)
    newmap.(networks{i}) = hex2rgb(hex_colors.(networks{i}));
end
end
