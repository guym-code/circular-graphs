sch_labels_path = '/Users/elaine/Downloads/Parcellations/Parcellations/HCP/fslr32k/cifti/Schaefer2018_100Parcels_7Networks_order_info.txt';
labels_fid = fopen(sch_labels_path);
schaefer_names = textscan(labels_fid, '%s');
schaefer_names = schaefer_names{1}(1:6:end);
schaefer_names = cellfun(@(s) s(11:end), schaefer_names, 'uniform', 0);

networks.Vis = [];
networks.DorsAttn = [];
networks.Default = [];
networks.SalVentAttn = [];
networks.SomMot = [];
networks.Cont = [];
networks.Limbic = [];

for i = 1:length(schaefer_names)
    label = schaefer_names{i};
    split_label = split(label, '_');
    network = split_label{2};
    networks.(network) = [networks.(network) i];
end
networks