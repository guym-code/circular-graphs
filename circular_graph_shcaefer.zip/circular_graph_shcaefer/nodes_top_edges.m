

load("/Volumes/homes/Maya/SAT_study/results/feature_importance/LRR/permutation_feature_importance/Global_Ridge(random_state=0)_permutation_feature_importance.mat")
matrix = permutation_feature_importance_mat;

% Only positive contributions
top_10 = maxk(unique(matrix(:)), 10);
threshold = min(top_10);
matrix(matrix<threshold) = 0;

% Find the linear indices of the top edges
top_indices = find(matrix >= threshold);

% Convert linear indices to subscript indices
[row, col] = ind2sub(size(matrix), top_indices);
edges = [row, col];

% Concatenate row and column indices
concat_indices = [row; col];

% Filter out duplicate pairs (because the matrix is symmetric)
unique_indices = unique(concat_indices);

schaefer_cifti=open_wbfile('/Volumes/homes/Maya/Atlases/schaefer_parcellation/Surface/Schaefer2018_100Parcels_7Networks_order.dlabel.nii');
atlas=schaefer_cifti.cdata;
fig=zeros(size(atlas));

for ind = 1:length(unique_indices)
    parcel_ind = unique_indices(ind);
    fig(atlas==parcel_ind)=parcel_ind;
end

dir_to_save = '/Volumes/homes/Maya/SAT_study/results/feature_importance/LRR/permutation_feature_importance/';
schaefer_cifti.cdata=fig;
ciftisave(schaefer_cifti, [dir_to_save, 'nodes_of_top_10_edges_verbal_permutation_feature_importance_map.dlabel.nii'])