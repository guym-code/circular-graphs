classdef circularGraph < handle
% CIRCULARGRAPH Plot an interactive circular graph to illustrate connections in a network.
%
%% Syntax
% circularGraph(X)
% circularGraph(X,'PropertyName',propertyvalue,...)
% h = circularGraph(...)
%
%% Description
% A 'circular graph' is a visualization of a network of nodes and their
% connections. The nodes are laid out along a circle, and the connections
% are drawn within the circle. Click on a node to make the connections that
% emanate from it more visible or less visible. Click on the 'Show All'
% button to make all nodes and their connections visible. Click on the
% 'Hide All' button to make all nodes and their connections less visible.
%
% Required input arguments.
% X : A symmetric matrix of numeric or logical values.
%
% Optional properties.
% Colormap : A N by 3 matrix of [r g b] triples, where N is the 
%            length(adjacenyMatrix).
% Label    : A cell array of N strings.
%%
% Copyright 2016 The MathWorks, Inc.
  properties
    Node = node(0,0); % Array of nodes
    NodeColorMap;         % Colormap for 7 Networks
    EdgeColorMap;         % Colormap for edge strength
    Label;            % Cell array of strings
    ShowButton;       % Turn all nodes on
    HideButton;       % Turn all nodes off
  end
  
  methods
    function [this, fig] = circularGraph(adjacencyMatrix,varargin)
      % Constructor
      p = inputParser;
      
      defaultColorMap = parula(length(adjacencyMatrix));
      defaultLabel = cell(length(adjacencyMatrix));
      for i = 1:length(defaultLabel)
        defaultLabel{i} = num2str(i);
      end
      
      % Find non-zero values of s and their indices
      [row,col,s] = find(adjacencyMatrix);
      sorted_s = sort(s);
      
      addRequired(p,'adjacencyMatrix',@(x)(isnumeric(x) || islogical(x)));
      addParameter(p,'Label'   ,defaultLabel   ,@iscell);
      addParameter(p,'NodeColorMap',defaultColorMap,@(colormap)length(fields(colormap)) == 7);
      addParameter(p,'EdgeColorMap',defaultColorMap,@(colormap)length(colormap) == length(adjacencyMatrix));
      
      parse(p,adjacencyMatrix,varargin{:});
      this.NodeColorMap = p.Results.NodeColorMap;
      this.EdgeColorMap = p.Results.EdgeColorMap;
      this.Label = p.Results.Label;
      
      % Create list of all networks
      NetworkList = [];
      for i = 1:length(this.Label)
          label_i = this.Label(i);
          split_label = split(label_i, '_');
          network = split_label(2);
          NetworkList = [NetworkList; network];
      end
      NetworkList = unique(NetworkList);
      
      this.ShowButton = uicontrol(...
        'Style','pushbutton',...
        'Position',[0 40 80 40],...
        'String','Show All',...
        'Callback',@circularGraph.showNodes,...
        'UserData',this);
      
      this.HideButton = uicontrol(...
        'Style','pushbutton',...
        'Position',[0 0 80 40],...
        'String','Hide All',...
        'Callback',@circularGraph.hideNodes,...
        'UserData',this);
      
      fig = gcf;
      fig = figure();
      set(fig,...
        'UserData',this,...
        'CloseRequestFcn',@circularGraph.CloseRequestFcn);
      
      % Draw the nodes
      delete(this.Node);
      t = linspace(-3*pi/2,pi/2,length(adjacencyMatrix) + 3).'; % theta for each node
      extent = zeros(length(adjacencyMatrix),1);
      for i = 1:(length(adjacencyMatrix)+2)
        if (i == 1) || (i==(ceil(2+length(adjacencyMatrix)/2)))
            % Top and bottom circles are white to separate hemispheres
            this.Node(i) = node(cos(t(i)),sin(t(i)));
            this.Node(i).Color = [1, 1, 1];
            this.Node(i).Label = '';
            this.Node(i).Size = 24;
            this.Node(i).FaceColor = [1, 1, 1];
        else
            if (i <= (1+(length(adjacencyMatrix)/2)))
            	node_label_split = split(this.Label{i-1}, '_');
            elseif (i > (2+length(adjacencyMatrix)/2))
                node_label_split = split(this.Label{i-2}, '_');
            end
            % Node color determined by its network
            node_network = node_label_split{2}; 
            node_color = this.NodeColorMap.(node_network);
            this.Node(i) = node(cos(t(i)),sin(t(i)));
            this.Node(i).FaceColor = node_color;
            this.Node(i).Label = '';
            this.Node(i).Size = 24;
        end
      end
      
      % Calculate line widths based on values of s (stored in v).
      minLineWidth  = 0;
      lineWidthCoef = 5;
      lineWidth = abs(s)./max(abs(s)) * 4;%s./max(s);
      %lineWidth = ones(length(s)) * 5 ; %abs(s)./max(abs(s));
      %lineColor = zeros(length(s), 3);
      lineColor = [1-(abs(s)./max(abs(s))) 1-(abs(s)./max(abs(s))) 1-(abs(s)./max(abs(s)))]; 
      %lineColor = [1-s./max(s), 1-s./max(s), 1-s./max(s)]; 
      % For red = positive \ blue = negative
      lineStyle = strings(length(s));
   
      for edge_ind = 1:length(s)
                if s(edge_ind)<0
                    %lineColor(edge_ind,:) = [0,0,0];%[0.3764705882352941, 0.42745098039215684, 0.6784313725490196];%  
                    lineStyle(edge_ind,:) = '--';
               else 
                    %lineColor(edge_ind,:) = [0,0,0];%[0.8862745098039215 0.5411764705882353 0.49019607843137253];
                    lineStyle(edge_ind,:) = '-';
               end
      end
        
    
%        if sum(lineWidth) == numel(lineWidth) % all lines are the same width.
%          lineWidth = repmat(minLineWidth,numel(lineWidth),1);
%        else % lines of variable width.
%          lineWidth = lineWidthCoef*lineWidth + minLineWidth;
%        end
%       
      % Draw connections on the Poincare hyperbolic disk.
      %
      % Equation of the circles on the disk:
      % x^2 + y^2 
      % + 2*(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1))*x 
      % - 2*(u(1)-v(1))/(u(1)*v(2)-u(2)*v(1))*y + 1 = 0,
      % where u and v are points on the boundary.
      %
      % Standard form of equation of a circle
      % (x - x0)^2 + (y - y0)^2 = r^2
      %
      % Therefore we can identify
      % x0 = -(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1));
      % y0 = (u(1)-v(1))/(u(1)*v(2)-u(2)*v(1));
      % r^2 = x0^2 + y0^2 - 1
      
      % after adding the white circles, the indices should change
      % so we change the indices for plotting the edges
      row_for_graph = row;
      col_for_graph = col;
      
      row_for_graph(row_for_graph>50) = row_for_graph(row_for_graph>50) + 2;
      row_for_graph(row_for_graph<=50) = row_for_graph(row_for_graph<=50) + 1;
      col_for_graph(col_for_graph>50) = col_for_graph(col_for_graph>50) + 2;
      col_for_graph(col_for_graph<=50) = col_for_graph(col_for_graph<=50) + 1;

      for i = 1:length(s)
        if row(i) ~= col(i)
          if abs(row(i) - col(i)) - length(adjacencyMatrix)/2 == 0 
            % points are diametric, so draw a straight line
            u = [cos(t(row_for_graph(i)));sin(t(row_for_graph(i)))];
            v = [cos(t(col_for_graph(i)));sin(t(col_for_graph(i)))];
            this.Node(row_for_graph(i)).Connection(end+1) = line(...
              [u(1);v(1)],...
              [u(2);v(2)],...
              'LineWidth', lineWidth(i),...
              'Color', lineColor(i, :),...
              'LineStyle', lineStyle(i),...
              'PickableParts','none');
          else % points are not diametric, so draw an arc
            u  = [cos(t(row_for_graph(i)));sin(t(row_for_graph(i)))];
            v  = [cos(t(col_for_graph(i)));sin(t(col_for_graph(i)))];
            x0 = -(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1));
            y0 =  (u(1)-v(1))/(u(1)*v(2)-u(2)*v(1));
            r  = sqrt(x0^2 + y0^2 - 1);
            thetaLim(1) = atan2(u(2)-y0,u(1)-x0);
            thetaLim(2) = atan2(v(2)-y0,v(1)-x0);
            
            if u(1) >= 0 && v(1) >= 0 
              % ensure the arc is within the unit disk
              theta = [linspace(max(thetaLim),pi,51),...
                       linspace(-pi,min(thetaLim),51)].';
            else
              theta = linspace(thetaLim(1),thetaLim(2)).';
            end
            
            this.Node(row_for_graph(i)).Connection(end+1) = line(...
              r*cos(theta)+x0,...
              r*sin(theta)+y0,...
              'LineWidth', lineWidth(i),...
              'LineStyle', lineStyle(i),...
              'Color', lineColor(i,:),...
              'PickableParts','none',...
              'MarkerFaceColor', this.Node(i).Color);
          end
        end
        %%% PRINT FOR DEBUG
%         {s(i); this.Label{row(i)}; this.Label{col(i)}}
      end
      
      axis image;
      ax = gca;
      for i = 1:length(adjacencyMatrix)
        extent(i) = this.Node(i).Extent;
      end
      extent = max(extent(:));
      ax.XLim = ax.XLim + extent*[-1 1];
      fudgeFactor = 1.75; % Not sure why this is necessary. Eyeballed it.
      ax.YLim = ax.YLim + fudgeFactor*extent*[-1 1];
      ax.Visible = 'off';
      ax.SortMethod = 'depth';
      
      fig = gcf;
      fig.Color = [1 1 1];
    end
    
  end
  
  methods (Static = true)
    function showNodes(this,~)
      % Callback for 'Show All' button
      n = this.UserData.Node;
      for i = 1:length(n)
        n(i).Visible = true;
      end
    end
    
    function hideNodes(this,~)
      % Callback for 'Hide All' button
      n = this.UserData.Node;
      for i = 1:length(n)
        n(i).Visible = false;
      end
    end
    
    function CloseRequestFcn(this,~)
      % Callback for figure CloseRequestFcn
      c = this.UserData;
      for i = 1:length(c.Node)
        delete(c.Node(i));
      end
      delete(gcf);
    end
    
  end
  
end